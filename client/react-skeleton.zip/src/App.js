import './App.css';

const App = () => {
  return (
    <div className="App">
      <h1>My App</h1>
    </div>
  );
};

export default App;
